<h1 style="color: darkblue;">Page 2</h1>

<?php

require("login_&_register.php");
login_form("POST");

 ?>