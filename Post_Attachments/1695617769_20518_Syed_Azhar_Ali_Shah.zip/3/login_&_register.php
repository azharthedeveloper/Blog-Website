<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Login & Registration Forms</title>
	<style type="text/css">
		body{
			background-color: lightgoldenrodyellow;
		}
		.login{
			border: 4px double brown;
			width: 20vw;
			padding: 20px;
			margin: 20px;
			color: brown;
		}
		.login legend{
			font-size: 20px;
			font-weight: bold;
			color: darkred;
		}
		.login input{
			margin: 5px;
			padding: 5px;
			color: darkred;
		}
		.login-btn{
			background-color: burlywood;
			border: none;
			border-radius: 4px;
			width: 75px;
			height: 30px;
			color: brown;
			cursor: pointer;
		}
		.login-btn:hover{
			background-color: brown;
			color: burlywood;
		}

		.registration{
			border: 4px double blueviolet;
			width: 35vw;
			padding: 20px;
			margin: 20px;
			color: blueviolet;
		}
		.registration legend{
			font-size: 20px;
			font-weight: bold;
			color: purple;
		}
		.registration input{
			margin: 5px;
			padding: 5px;
			color: purple;
		}
		.registration .register-btn{
			background-color: blueviolet;
			border: none;
			border-radius: 4px;
			width: 75px;
			height: 30px;
			cursor: pointer;
			color: white;
		}
		.register-btn:hover{
			background-color: white;
			color: blueviolet;
			border: 1px solid blueviolet;
		}
	</style>
</head>
<body>
	<?php 
		function login_form($method, $action = "")
		{
	?>
	<center>
		<fieldset class="login">
			<legend>LOGIN Here..!</legend>
			<form action="<?php echo $action ?>" method="<?php echo $method ?>">
				<table>
					<tr>
						<td><label>Username: </label></td>
						<td><input type="text" name="username" placeholder="Enter your Username" required></td>
					</tr>
					<tr>
						<td><label>Password: </label></td>
						<td><input type="password" name="password" placeholder="Enter your Password" required></td>
					</tr>
					<tr>
						<td align="center" colspan="2"><input class="login-btn" type="submit" name="login" value="Login"></td>
					</tr>
				</table>
			</form>
		</fieldset>
	</center>
	<?php
		}
	 ?>



	<?php 
		function registration_form($method, $action = "")
		{
	?>
	<center>
		<fieldset class="registration">
	<legend>REGISTER Here..!</legend>
	<form action="<?php echo $action ?>" method="<?php echo $method ?>">
		<table>
			<tr>
				<td><label>Full Name:</label></td>
				<td><input type="text" name="fullname" placeholder="Enter your Full Name" required></td>
			</tr>
			<tr>
				<td><label>Email:</label></td>
				<td><input type="email" name="email" placeholder="Enter your Email" required></td>
			</tr>
			<tr>
				<td><label>Username:</label></td>
				<td><input type="text" name="username" placeholder="Enter your Username" required></td>
			</tr>
			<tr>
				<td><label>Password:</label></td>
				<td><input type="password" name="password" placeholder="Enter your Password" required></td>
			</tr>
			<tr>
				<td><label>Gender:</label></td>
				<td>
					<label><input type="radio" name="gender" value="male" required> Male</label>
					<label><input type="radio" name="gender" value="female" required> Female</label>
				</td>
			</tr>
			<tr>
				<td><label>Country:</label></td>
				<td>
					<select name="country" required>
						<option value="">Select your country</option>
						<option value="Pakistan">Pakistan</option>
						<option value="India">India</option>
						<option value="Bangladesh">Bangladesh</option>
						<option value="Iran">Iran</option>
						<option value="China">China</option>
						<option value="Other">Other</option>
					</select>
				</td>
			</tr>
			<tr>
				<td align="center" colspan="2"><input class="register-btn" type="submit" name="register" value="Register"></td>
			</tr>
		</table>
	</form>
</fieldset>
	</center>
	<?php
		}
	 ?>


</body>
</html>