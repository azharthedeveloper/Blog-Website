<h1 style="color: darkred;">Page 1</h1>
<?php 

include("login_&_register.php");
login_form("GET", "");

registration_form("POST");

?>