<h1 style="color: darkgoldenrod;">Page 3</h1>

<?php

require_once("login_&_register.php");
registration_form("GET", "page_1.php");

 ?>