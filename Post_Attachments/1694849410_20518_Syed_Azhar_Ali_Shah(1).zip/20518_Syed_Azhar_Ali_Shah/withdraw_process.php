<?php

require 'require/database_setting.php';
require 'require/bank_class.php';

if (isset($_REQUEST['withdraw'])) {
	echo "<pre>";
	print_r($_REQUEST);
	echo "</pre>";

	extract($_REQUEST);

	if ($withdraw_amount > 0) {
		$obj = new bankClass($hostname,$username,$password,$database_name);
		$result = $obj->withdraw($account_number,$withdraw_amount);
		if ($result) {
			$msg="Amount: $withdraw_amount has been Withdraw from your Account ";
			$color='green';
			header("location: withdraw.php?msg=$msg&color=$color");
		}else{
			$msg="Amount Cannot be Withdraw from your Account ";
			$color='red';
			header("location: withdraw.php?msg=$msg&color=$color");
		}
	}else{
		$msg="Please, increase your Withdraw Amount";
		$color='red';
		header("location: withdraw.php?msg=$msg&color=$color");
	}
}

 ?>