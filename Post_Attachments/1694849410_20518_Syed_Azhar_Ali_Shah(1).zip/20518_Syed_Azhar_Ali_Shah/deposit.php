<?php


require 'require/form_class.php';
$form = new formClass;
$form->set_action("deposit_process.php");
$form->set_method("POST");
 ?>
 <!DOCTYPE html>
 <html lang="en">
 <head>
 	<meta charset="UTF-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1.0">
 	<title>Deposit Amount</title>
    <style type="text/css">
        body{
            background-color: lightsteelblue;
        }
        h1{
            background-color: blue;
            color: white;
            padding: 10px;
            margin: 5px 30px;
            border-radius: 10px;
        }
        fieldset{
            width: 30%;
            border: 4px dashed darkcyan;
            color: white;
        }
        legend{
            font-size: 18px;
            font-weight: bold;
            color: darkslateblue;
        }
    </style>
 </head>
 <body>
 	<center>
 		<h1>Deposit Amount</h1>
 		<?php $form->deposit_form(); ?>
 	</center>
 </body>
 </html>