<?php

require 'require/database_setting.php';
require 'require/bank_class.php';

if (isset($_REQUEST['deposit'])) {
	echo "<pre>";
	print_r($_REQUEST);
	echo "</pre>";

	extract($_REQUEST);

	if ($deposit_amount > 0) {
		$obj = new bankClass($hostname,$username,$password,$database_name);
		$result = $obj->deposit($account_number, $deposit_amount);
		if ($result) {
			$msg="Amount: $deposit_amount Deposited in your Account";
			$color='green';
			header("location: deposit.php?msg=$msg&color=$color");
		}else{
			$msg="Amount Cannot be Deposited in your Account";
			$color='red';
			header("location: deposit.php?msg=$msg&color=$color");
		}

	}else{
		$msg="Please, increase your Deposit Amount";
		$color='red';
		header("location: deposit.php?msg=$msg&color=$color");
	}
}


 ?>