<?php

require 'require/database_setting.php';
require 'require/bank_class.php';

if (isset($_REQUEST['register'])) {
	echo "<pre>";
	print_r($_REQUEST);
	echo "</pre>";

	extract($_REQUEST);

	if ($bank_balance > 0) {
		$obj = new bankClass($hostname,$username,$password,$database_name);
		$result = $obj->user_information($full_name,$email,$phone_number,$account_number,$bank_balance);
		if ($result) {
			// echo "Your Account is Opened";
			$msg="Your Account is Opened";
			$color='green';
			header("location: register.php?msg=$msg&color=$color");
		}else{
			// echo "Your Account cannot be Opened";
			$msg="Your Account cannot be Opened";
			$color='red';
			header("location: register.php?msg=$msg&color=$color");
		}
	}else{
		$msg="Please, increase your Bank Balance";
		$color='red';
		header("location: register.php?msg=$msg&color=$color");
	}
}


 ?>