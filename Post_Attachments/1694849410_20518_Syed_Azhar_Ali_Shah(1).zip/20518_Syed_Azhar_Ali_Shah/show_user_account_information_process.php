<?php

require 'require/database_setting.php';
require 'require/bank_class.php';


if (isset($_REQUEST['show_user'])) {
	// echo "<pre>";
	// print_r($_REQUEST);
	// echo "</pre>";

	extract($_REQUEST);

	$obj = new bankClass($hostname,$username,$password,$database_name);
	$result = $obj->show_user_account_information($account_number);

	if ($result->num_rows > 0) {
		$row = mysqli_fetch_assoc($result);
		?>
		<style type="text/css">
			body{
 			background-color: lightsteelblue;
 		}
 		h1{
 			background-color: blue;
 			color: white;
 			padding: 10px;
 			margin: 5px 30px;
 			border-radius: 10px;
 		}
 		h4{
 			background-color: blueviolet;
 			color: yellow;
 			padding: 10px;
 			margin: 5px 100px;
 			border-radius: 10px;
 		}
 		table{
 			color: purple;
 		}
		</style>
		<center>
			<h1>User Account Information</h1>
			<h4>Hello! <?php echo $row['full_name'] ?></h4>
			<table border="2" cellpadding="4" cellspacing="4">
				<tr>
					<td>Full Name: </td>
					<td><?php echo $row['full_name'] ?></td>
				</tr>
				<tr>
					<td>Email: </td>
					<td style="color: blue;"><?php echo $row['email'] ?></td>
				</tr>
				<tr>
					<td>Phone Number: </td>
					<td><?php echo $row['phone_number'] ?></td>
				</tr>
				<tr>
					<td>Bank Account Number: </td>
					<td><?php echo $row['account_number'] ?></td>
				</tr>
				<tr>
					<td>Bank Balance: </td>
					<td><?php echo $row['bank_balance'] ?></td>
				</tr>
			</table>
		</center>
		<?php
	}

}

 ?>