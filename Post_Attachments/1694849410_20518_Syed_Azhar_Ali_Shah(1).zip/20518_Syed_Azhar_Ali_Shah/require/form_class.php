<?php


class formClass{
	public $action;
	public $method = 'GET';

	public function set_action($action){
		$this->action = $action;
	}
	public function get_action(){
		return $this->action;
	}

	public function set_method($method){
		$this->method = $method;
	}
	public function get_method(){
		return $this->method;
	}

	public function register_form(){
		?>
		<fieldset>
			<legend>Bank System Registeration</legend>
			<form action="<?php echo $this->get_action(); ?>" method="<?php echo $this->get_method(); ?>">
				<table>
					<tr>
						<td align="center" colspan="2">
							<?php
							if (isset($_GET['msg'])) {
								?>
								<span style="color: <?php echo $_GET['color'] ?>;"><?php echo $_GET['msg'] ?></span>
								<?php
							}
							 ?>
						</td>
					</tr>
					<tr>
						<td>Full Name: </td>
						<td><input type="text" name="full_name" required></td>
					</tr>
					<tr>
						<td>Email: </td>
						<td><input type="email" name="email" required></td>
					</tr>
					<tr>
						<td>Phone Number: </td>
						<td><input type="text" name="phone_number" required></td>
					</tr>
					<tr>
						<td>Bank Account Number: </td>
						<td><input type="text" name="account_number" required></td>
					</tr>
					<tr>
						<td>Bank Balance: </td>
						<td><input type="text" name="bank_balance" required></td>
					</tr>
					<tr>
						<td align="center" colspan="2"><input type="submit" name="register" value="Open Account"></td>
					</tr>
				</table>
			</form>
		</fieldset>
		<?php
	}

	public function deposit_form(){
		?>
		<fieldset>
			<legend>Deposit Amount</legend>
			<form action="<?php echo $this->get_action(); ?>" method="<?php echo $this->get_method(); ?>">
				<table>
					<tr>
						<td align="center" colspan="2">
							<?php
							if (isset($_GET['msg'])) {
								?>
								<span style="color: <?php echo $_GET['color'] ?>;"><?php echo $_GET['msg'] ?></span>
								<?php
							}
							 ?>
						</td>
					</tr>
					<tr>
						<td>Bank Account Number: </td>
						<td><input type="text" name="account_number" required></td>
					</tr>
					<tr>
						<td>Amount to be Deposit: </td>
						<td><input type="text" name="deposit_amount" required></td>
					</tr>
					<tr>
						<td align="center" colspan="2"><input type="submit" name="deposit" value="Deposit"></td>
					</tr>
				</table>
			</form>
		</fieldset>
		<?php
	}

	public function withdraw_form(){
		?>
		<fieldset>
			<legend>Withdraw Amount</legend>
			<form action="<?php echo $this->get_action(); ?>" method="<?php echo $this->get_method(); ?>">
				<table>
					<tr>
						<td align="center" colspan="2">
							<?php
							if (isset($_GET['msg'])) {
								?>
								<span style="color: <?php echo $_GET['color'] ?>;"><?php echo $_GET['msg'] ?></span>
								<?php
							}
							 ?>
						</td>
					</tr>
					<tr>
						<td>Bank Account Number: </td>
						<td><input type="text" name="account_number" required></td>
					</tr>
					<tr>
						<td>Amount to be Withdraw: </td>
						<td><input type="text" name="withdraw_amount" required></td>
					</tr>
					<tr>
						<td align="center" colspan="2"><input type="submit" name="withdraw" value="Withdraw"></td>
					</tr>
				</table>
			</form>
		</fieldset>
		<?php
	}

	public function show_user_form(){
		?>
		<fieldset>
			<legend>Show User</legend>
			<form action="<?php echo $this->get_action(); ?>" method="<?php echo $this->get_method(); ?>">
				<table>
					<tr>
						<td align="center" colspan="2">
							<?php
							if (isset($_GET['msg'])) {
								?>
								<span style="color: <?php echo $_GET['color'] ?>;"><?php echo $_GET['msg'] ?></span>
								<?php
							}
							 ?>
						</td>
					</tr>
					<tr>
						<td>Bank Account Number: </td>
						<td><input type="text" name="account_number" required></td>
					</tr>
					<tr>
						<td align="center" colspan="2"><input type="submit" name="show_user" value="Show"></td>
					</tr>
				</table>
			</form>
		</fieldset>
		<?php
	}
}


 ?>