<?php

require 'database_setting.php';

class bankClass{
	public $hostname;
	public $username;
	public $password;
	public $database_name;
	public $connection;
	public $insert_query;
	public $update_query;
	public $select_query;
	public $result;

	public function __construct($hostname,$username,$password,$database_name){
		$this->hostname = $hostname;
		$this->username = $username;
		$this->password = $password;
		$this->database_name = $database_name;

		mysqli_report(FALSE);
		$this->connection = mysqli_connect($this->hostname,$this->username,$this->password,$this->database_name);
		if (mysqli_connect_errno()) {
			echo "<p style='color:red'> Error Message: ".mysqli_connect_error()."</p>";
			echo "<p style='color:red'> Error Code: ".mysqli_connect_errno()."</p>";
		}
	}

	public function user_information($full_name,$email,$phone_number,$account_number,$bank_balance){
		$this->insert_query = "INSERT INTO users(full_name,email,phone_number,account_number,bank_balance)
		VALUES('{$full_name}','{$email}','{$phone_number}','{$account_number}', '{$bank_balance}')";
		$this->result = mysqli_query($this->connection,$this->insert_query);

		return $this->result;
	}

	public function deposit($account_number,$amount){
		$this->update_query = "UPDATE users SET bank_balance = bank_balance + '{$amount}' WHERE account_number = '{$account_number}'";
		$this->result = mysqli_query($this->connection,$this->update_query);

		return $this->result;
	}

	public function withdraw($account_number,$amount){
		$this->update_query = "UPDATE users SET bank_balance = bank_balance - '{$amount}' WHERE account_number = '{$account_number}' AND bank_balance >= '{$amount}'";
		$this->result = mysqli_query($this->connection,$this->update_query);

		return $this->result;
	}

	public function show_user_account_information($account_number){
		$this->select_query = "SELECT * FROM users WHERE account_number = '{$account_number}'";
		$this->result = mysqli_query($this->connection, $this->select_query);

		return $this->result;
	}
}


 ?>