<?php 

$hostname = 'localhost';
$username = 'root';
$password = '';
$database_name = 'bank_system';


?>